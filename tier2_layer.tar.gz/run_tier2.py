#!/usr/bin/env python3
"""
VULCAN Tier-2: execution-PROVEN exploitation (curated).

Pipeline:
  1. Find every (candidate, sample) that Tier 1 flags TRIGGERED -- a tainted
     value reached a dangerous sink -- recording its CWE and injected param.
  2. For a curated subset (first triggering sample per candidate+CWE, capped
     per CWE), dispatch to the matching Tier-2 strategy and attempt to PROVE
     exploitation: run real attacker payloads through the real code in live
     mode and check for a real observable effect.
  3. Report CONFIRMED_EXPLOITABLE only when the observable fired, with the
     exact payload and proof artifact -- fully auditable.

The detection oracle is untouched and never agentic. --use-agent only lets an
LLM *craft* payloads; the deterministic observable check still decides.

USAGE (local, free):
  export OPENSOURCE_BASE_URL=http://localhost:11434/v1
  python3 run_tier2.py --candidates calibration/mined_prompts/invoke/ --model qwen2.5-coder:7b
  # add the agentic crafter on top of the deterministic bank:
  python3 run_tier2.py --candidates calibration/mined_prompts/sqlite-utils/ --model qwen2.5-coder:7b --use-agent --max-agent 4
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(_REPO / "analysis" / "iast"))
sys.path.insert(0, str(_REPO))

from auto_harness import run_candidate            # noqa: E402
from run_benchmark import reduce_verdicts          # noqa: E402
from tier2.engine import attempt_exploit           # noqa: E402
from tier2.strategies import STRATEGIES            # noqa: E402


def _iter_samples(gens: dict):
    t0 = gens.get("temp_0_0")
    if t0 and t0.get("ok") and t0.get("source"):
        yield ("temp_0_0", t0["source"])
    for i, s in enumerate(gens.get("temp_0_7", [])):
        if s.get("ok") and s.get("source"):
            yield (f"temp_0_7[{i}]", s["source"])


def find_triggered(files: list, model: str) -> list:
    """One representative triggering sample per (candidate, CWE)."""
    seen = set()
    out = []
    for path in files:
        record = json.loads(path.read_text())
        gens = record.get("generations", {}).get(model)
        if not gens:
            continue
        func = record.get("function", path.stem)
        for slot, source in _iter_samples(gens):
            r = dict(record)
            r["generated_source"] = source
            red = reduce_verdicts(run_candidate(r, use="generated"))
            if red["verdict"] != "TRIGGERED":
                continue
            cwe, param = red.get("cwe"), red.get("param")
            key = (func, cwe)
            if key in seen:
                continue
            seen.add(key)
            out.append({"path": path, "record": record, "func": func, "slot": slot,
                        "source": source, "cwe": cwe, "param": param})
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--candidates", required=True, type=Path)
    ap.add_argument("--model", required=True, help="which model's TRIGGERED samples to attack")
    ap.add_argument("--max-per-cwe", type=int, default=10, help="curate: cap attempts per CWE")
    ap.add_argument("--use-agent", action="store_true", help="also let an LLM craft payloads (after the bank)")
    ap.add_argument("--max-agent", type=int, default=4, help="bounded agent attempts per candidate (with --use-agent)")
    ap.add_argument("--base-url", default=os.environ.get("OPENSOURCE_BASE_URL", "http://localhost:11434/v1"))
    ap.add_argument("--agent-model", default=None, help="model for the agent crafter (default: --model)")
    ap.add_argument("--out", type=Path, default=None, help="results JSON (default: <candidates>/tier2_results.json)")
    args = ap.parse_args()

    files = ([args.candidates] if args.candidates.is_file()
             else sorted(p for p in args.candidates.glob("*.json")
                         if p.name not in ("auto_harness_results.json", "benchmark_results.json", "tier2_results.json")))
    files = [p for p in files if "prompt_source" in json.loads(p.read_text())]

    agent_call = None
    if args.use_agent:
        from generate_batch import make_caller
        agent_call = make_caller(args.base_url, args.agent_model or args.model)

    print(f"Tier-2 | model={args.model} | candidates={args.candidates} | agent={'on' if agent_call else 'off'}",
          file=sys.stderr)
    triggered = find_triggered(files, args.model)
    print(f"Tier-1 TRIGGERED (representative per candidate+CWE): {len(triggered)}", file=sys.stderr)

    # curate per CWE
    per_cwe_count: dict = {}
    results = []
    for t in triggered:
        cwe = t["cwe"]
        if cwe not in STRATEGIES:
            results.append({"func": t["func"], "slot": t["slot"], "cwe": cwe, "param": t["param"],
                            "confirmed": False, "reason": f"no Tier-2 strategy for {cwe}"})
            continue
        if per_cwe_count.get(cwe, 0) >= args.max_per_cwe:
            continue
        per_cwe_count[cwe] = per_cwe_count.get(cwe, 0) + 1

        rec = dict(t["record"])
        rec["generated_source"] = t["source"]
        print(f"  exploit  {t['func']}  {cwe}  param={t['param']} ...", file=sys.stderr, flush=True)
        res = attempt_exploit(rec, t["param"], cwe, use="generated",
                              agent_call=agent_call, max_agent=args.max_agent)
        res.update({"func": t["func"], "slot": t["slot"]})
        results.append(res)
        if res.get("confirmed"):
            print(f"    CONFIRMED via {res.get('via')}: {res.get('proof')}", file=sys.stderr, flush=True)

    # ---- summary ----
    by_cwe: dict = {}
    for r in results:
        c = r["cwe"]
        by_cwe.setdefault(c, {"attempted": 0, "confirmed": 0})
        if "reason" in r and r.get("reason", "").startswith("no Tier-2"):
            continue
        by_cwe[c]["attempted"] += 1
        if r.get("confirmed"):
            by_cwe[c]["confirmed"] += 1

    print("\n" + "=" * 70)
    print(f"VULCAN TIER-2 (execution-proven exploitation) -- model={args.model}")
    print("=" * 70)
    total_a = total_c = 0
    for cwe in sorted(by_cwe):
        a, c = by_cwe[cwe]["attempted"], by_cwe[cwe]["confirmed"]
        total_a += a
        total_c += c
        strat = STRATEGIES.get(cwe)
        print(f"  {cwe} ({strat.name if strat else '?'}): CONFIRMED_EXPLOITABLE {c}/{a}")
    print("-" * 70)
    print(f"  TOTAL: {total_c}/{total_a} TRIGGERED candidates proven exploitable")
    print("=" * 70)
    confirmed = [r for r in results if r.get("confirmed")]
    if confirmed:
        print("\nProofs:")
        for r in confirmed:
            print(f"  [{r['cwe']}] {r['func']} ({r['slot']}) via {r.get('via')}")
            print(f"      payload: {r.get('payload')!r}")
            print(f"      proof  : {r.get('proof')}")
    print("\nNote: CONFIRMED_EXPLOITABLE means a real observable effect was produced by")
    print("real execution (not the sink merely firing). NOT_CONFIRMED includes read-only")
    print("exfiltration that needs output capture (a documented v2 extension), so it is")
    print("not evidence of safety -- only that this side-effect prober did not confirm it.")

    out_path = (args.out if args.out
                else (args.candidates.parent if args.candidates.is_file() else args.candidates) / "tier2_results.json")
    out_path.write_text(json.dumps({"model": args.model, "results": results, "by_cwe": by_cwe}, indent=2))
    print(f"\nFull auditable results: {out_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
